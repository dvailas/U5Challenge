# Dylan Vailas
# Red River College
# September 22nd/2018

require_relative 'ar.rb'

products = Product.where("stock_quantity > 40")

products.each do |w|
  w.stock_quantity = w.stock_quantity + 1
  w.save
end