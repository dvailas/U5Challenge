# Dylan Vailas
# Red River College
# September 22nd/2018

require_relative 'ar.rb'

number_of_products = Product.count

puts "There are #{number_of_products} in the products table."

product = Product.first

puts product.inspect
# Product Id
# Name
# Description
#Price
# Stock_quantity
# Category_id
#Created_at
#updated_at
#Product has a association to the category table

expensive_product = Product.where("price > 10").where("name LIKE 'C%'")
puts expensive_product.inspect

product_under_five = Product.where("stock_quantity < 5")
puts product_under_five.inspect

beverages = product.category
puts beverages.name

new_one = beverages.products.build( :name => 'Beer',
  :description => 'Fort Gary Dark Ale',
  :price => '3',
  :stock_quantity => '20')

  if(!new_one.save)
    puts new_one.errors.messages.inspect
  end

expensive_beverage =beverages.products.where("price > 5")
puts expensive_beverage.inspect

expensive_product = Product.where("price > 10").where("name LIKE 'Beer'")
