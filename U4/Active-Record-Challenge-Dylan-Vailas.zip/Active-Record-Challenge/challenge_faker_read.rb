# Dylan Vailas
# Red River College
# September 22nd/2018

require_relative 'ar.rb'

categories = Category.all

categories.each do |c|
  puts "**#{c.name}**"
      c.products.each do |w|
      puts "Product: #{w.name} Price: #{w.price}"
      puts "---------"
    end
end