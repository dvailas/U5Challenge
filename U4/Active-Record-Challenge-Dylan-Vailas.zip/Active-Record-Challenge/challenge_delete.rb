# Dylan Vailas
# Red River College
# September 22nd/2018

require_relative 'ar.rb'

products = Product.where("name = 'Red Bull'")

products.destroy_all
