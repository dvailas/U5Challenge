# Dylan Vailas
# Red River College
# September 22nd/2018

require_relative 'ar.rb'

# Name
# Description
#Price
# Stock_quantity
# Category_id
#Created_at
#updated_at

corn_flakes = Product.new


corn_flakes.name  = "Corn Flakes"
corn_flakes.description = "Kelogg's Corn Flakes"
corn_flakes.price  = "10"
corn_flakes.stock_quantity  = "11"


corn_flakes.save

red_bull = Product.new( :name  => "Red Bull",
  :description => "Red Bull Energy Drink",
  :price  => "3",
  :stock_quantity => "50")

red_bull.save

  big_steak = Product.create( :name  => "Big Steak",
    :description => "10oz Prime Rib Steak",
    :price  => "15",
    :stock_quantity => "25" )

    big_steak = Product.new( :name  => "Steak",
      :description => "10oz Prime Rib Steak",
      :stock_quantity => "25" )

      if(!big_steak.save)
        puts big_steak.errors.messages.inspect
      end