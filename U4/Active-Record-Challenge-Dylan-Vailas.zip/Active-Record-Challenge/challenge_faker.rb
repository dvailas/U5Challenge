# Dylan Vailas
# Red River College
# September 22nd/2018

require_relative 'ar.rb'

i = 0
num = 10
begin
  new_category = Category.new( :name  => Faker::Seinfeld.unique.character ,
    :description => Faker::Food.description)
    j = 0
    num2 = 10
  new_category.save
    begin
    new_product = new_category.products.build( :name => Faker::Food.unique.dish,
      :description => Faker::Food.description,
      :price => Faker::Commerce.price,
      :stock_quantity => Faker::Number.number(12))
    new_product.save
      j += 1
    end while j < num2

   i +=1
end while i < num